import React from 'react'

const Chapter = () => {
  return (
    <div>Chapter</div>
  )
}

export default Chapter