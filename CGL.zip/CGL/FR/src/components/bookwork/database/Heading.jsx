import React from 'react'

const Heading = () => {
  return (
    <div>Heading</div>
  )
}

export default Heading