import React from 'react'

const SubHeading = () => {
  return (
    <div>SubHeading</div>
  )
}

export default SubHeading