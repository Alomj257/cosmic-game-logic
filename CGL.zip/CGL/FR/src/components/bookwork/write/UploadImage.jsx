import React from 'react'

const UploadImage = () => {
  return (
    <div>UploadImage</div>
  )
}

export default UploadImage