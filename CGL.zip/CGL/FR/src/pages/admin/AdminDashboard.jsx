import React from 'react'

const AdminDashboard = () => {
  return (
    <div className="flex flex-col h-[90vh]">AdminDashboard</div>
  )
}

export default AdminDashboard